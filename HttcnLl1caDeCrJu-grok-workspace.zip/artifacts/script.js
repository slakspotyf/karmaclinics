/* Karma Dental Clinic — FR primary, EN optional + clinic assistant */

(function () {
  "use strict";

  const PHONE = "0774080545";
  const WA = "https://wa.me/213774080545";
  const CAPACITY = 2;
  const SLOT_HOURS = [8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20];
  const STORE_KEY = "karma-clinic-bookings";
  const LANG_KEY = "karma-lang";

  const I18N = {
    fr: {
      "sticky.call": "APPELEZ — 0774080545",
      "sticky.wa": "WHATSAPP",
      "nav.menu": "MENU",
      "nav.menuAria": "Ouvrir le menu",
      "nav.closeAria": "Fermer le menu",
      "nav.homeAria": "Accueil Karma Dental Clinic",
      "nav.home": "ACCUEIL",
      "nav.about": "À PROPOS",
      "nav.services": "SOINS",
      "nav.why": "POURQUOI NOUS",
      "nav.contact": "CONTACT",
      "nav.book": "RÉSERVER UNE PLACE",
      "nav.call": "APPELER 0774080545",
      "hero.eyebrow": "HYDRA · ALGER · ALGÉRIE",
      "hero.sub": "OUVERT 24H/24 · DES SOINS DÈS QUE VOUS EN AVEZ BESOIN",
      "hero.call": "APPELEZ — 0774080545",
      "hero.wa": "ÉCRIRE SUR WHATSAPP",
      "hero.book": "RÉSERVER UNE PLACE",
      "hero.alt": "Intérieur moderne de Karma Dental Clinic",
      "services.title": "NOS SOINS",
      "services.link": "VOIR LE CONTACT",
      "services.intro": "Karma Dental Clinic propose des soins dentaires à Hydra, Alger. Pour discuter de votre besoin, appelez-nous ou écrivez-nous. Ouvert 24 heures sur 24, tous les jours.",
      "services.general.title": "DENTISTERIE GÉNÉRALE",
      "services.general.desc": "Contrôles, détartrages et prévention pour garder un sourire en bonne santé.",
      "services.emergency.title": "URGENCES",
      "services.emergency.desc": "Ouvert 24h/24 pour la douleur, un choc ou un accident dentaire. Réponse rapide.",
      "services.cosmetic.title": "ESTHÉTIQUE & RESTAURATION",
      "services.cosmetic.desc": "Soins pour retrouver la fonction et l’apparence. Demandez une consultation.",
      "services.book": "RÉSERVER UNE PLACE",
      "services.assist": "OUVRIR L’ASSISTANT",
      "services.note": "[AJOUTER LA LISTE RÉELLE DES SOINS FOURNIE PAR LA CLINIQUE]",
      "about.title": "À PROPOS",
      "about.link": "NOUS ÉCRIRE",
      "about.p1": "Karma Dental Clinic est un cabinet dentaire situé à Hydra, Alger, Algérie. Nous sommes ouverts 24 heures sur 24, 7 jours sur 7, pour vous recevoir dès qu’un besoin dentaire se présente.",
      "about.p2": "Le cabinet se trouve Chemin de la Madeleine, Villa N12, Bourssace, Hydra 16016. Soins de routine ou urgence : l’équipe est là.",
      "about.call": "Appelez le",
      "about.orwa": "ou WhatsApp pour une réponse immédiate.",
      "about.stat1": "OUVERT CHAQUE JOUR",
      "about.stat2": "ALGER, ALGÉRIE",
      "why.title": "POURQUOI NOUS",
      "why.link": "APPELEZ AUJOURD’HUI",
      "why.b1.title": "OUVERT 24H/24",
      "why.b1.desc": "Des soins à toute heure. Pas besoin d’attendre le matin si la douleur arrive la nuit.",
      "why.b2.title": "HYDRA, FACILE D’ACCÈS",
      "why.b2.desc": "Chemin de la Madeleine, Villa N12, Bourssace, Hydra 16016 — au cœur d’Alger.",
      "why.b3.title": "CONTACT DIRECT",
      "why.b3.desc": "Appelez ou WhatsApp 0774080545. Parlez directement à la clinique, sans file d’attente.",
      "why.b4.title": "SOINS PROFESSIONNELS",
      "why.b4.desc": "Un cadre clinique moderne, concentré sur la qualité des soins.",
      "reviews.title": "AVIS PATIENTS",
      "reviews.placeholder": "[AJOUTER UN VRAI TÉMOIGNAGE]",
      "reviews.author": "— Nom du patient",
      "contact.title": "CONTACT",
      "contact.link": "APPELER 0774080545",
      "contact.phone": "TÉLÉPHONE",
      "contact.address": "ADRESSE",
      "contact.hours": "HORAIRES",
      "contact.hoursVal": "OUVERT 24H/24<br>TOUS LES JOURS",
      "contact.map": "PLAN",
      "contact.mapHint": "Carte ci-dessous — Hydra, Alger",
      "contact.mapCta": "OUVRIR GOOGLE MAPS",
      "form.name": "NOM",
      "form.namePh": "VOTRE NOM",
      "form.phone": "TÉLÉPHONE",
      "form.phonePh": "VOTRE NUMÉRO",
      "form.message": "MESSAGE",
      "form.messagePh": "COMMENT POUVONS-NOUS VOUS AIDER ?",
      "form.send": "ENVOYER",
      "form.or": "Ou appelez le",
      "map.prompt": "NOUS TROUVER À HYDRA, ALGER",
      "map.cta": "OUVRIR GOOGLE MAPS",
      "footer.tag": "Ouvert 24h/24 · Hydra, Alger",
      "footer.copy": "© 2026 Karma Dental Clinic. Tous droits réservés.",
      "chat.launcher": "ASSISTANT",
      "chat.title": "ASSISTANT CLINIQUE",
      "chat.status": "En ligne · Places · 24h/24",
      "chat.closeAria": "Fermer l’assistant",
      "chat.inputLabel": "Message",
      "chat.placeholder": "Un soin, un rendez-vous, une place…",
      "chat.send": "ENVOYER",
      "chat.sendAria": "Envoyer",
      "chat.you": "Vous",
      "chat.bot": "Assistant",
      "svc.general.label": "Dentisterie générale",
      "svc.general.copy": "Contrôle, détartrage et prévention. Une visite dure environ 45 minutes.",
      "svc.emergency.label": "Urgences",
      "svc.emergency.copy": "Douleur, dent cassée, gonflement ou choc. Ouvert 24h/24 — le plus rapide est d’appeler.",
      "svc.cosmetic.label": "Esthétique & restauration",
      "svc.cosmetic.copy": "Retrouver fonction et apparence. Nous commençons par une consultation.",
      "chip.book": "Réserver une place",
      "chip.spots": "Places libres",
      "chip.services": "Soins",
      "chip.emergency": "Urgence",
      "chip.hours": "Horaires & adresse",
      "chip.mine": "Mes rendez-vous",
      "chip.call": "Appeler " + PHONE,
      "chip.wa": "WhatsApp",
      "chip.stillBook": "Réserver quand même",
      "chip.bookGeneral": "Réserver général",
      "chip.bookCosmetic": "Réserver esthétique",
    },
    en: {
      "sticky.call": "CALL NOW — 0774080545",
      "sticky.wa": "WHATSAPP",
      "nav.menu": "MENU",
      "nav.menuAria": "Open menu",
      "nav.closeAria": "Close menu",
      "nav.homeAria": "Karma Dental Clinic home",
      "nav.home": "HOME",
      "nav.about": "ABOUT",
      "nav.services": "SERVICES",
      "nav.why": "WHY US",
      "nav.contact": "CONTACT",
      "nav.book": "BOOK A SPOT",
      "nav.call": "CALL 0774080545",
      "hero.eyebrow": "HYDRA · ALGER · ALGERIA",
      "hero.sub": "OPEN 24 HOURS · PROFESSIONAL CARE WHEN YOU NEED IT",
      "hero.call": "CALL NOW — 0774080545",
      "hero.wa": "MESSAGE ON WHATSAPP",
      "hero.book": "BOOK A SPOT",
      "hero.alt": "Modern interior of Karma Dental Clinic",
      "services.title": "OUR SERVICES",
      "services.link": "CONTACT FOR DETAILS",
      "services.intro": "Karma Dental Clinic provides professional dental care in Hydra, Alger. Call or message us to discuss your needs. We are open 24 hours every day.",
      "services.general.title": "GENERAL DENTISTRY",
      "services.general.desc": "Routine check-ups, cleanings, and preventive care to keep your smile healthy.",
      "services.emergency.title": "EMERGENCY CARE",
      "services.emergency.desc": "Open 24 hours for urgent dental issues. Fast response when pain or trauma strikes.",
      "services.cosmetic.title": "COSMETIC & RESTORATIVE",
      "services.cosmetic.desc": "Treatments to restore function and enhance appearance. Ask for a consultation.",
      "services.book": "BOOK A SPOT",
      "services.assist": "OPEN ASSISTANT",
      "services.note": "[ADD THE REAL SERVICE LIST FROM THE CLINIC]",
      "about.title": "ABOUT",
      "about.link": "GET IN TOUCH",
      "about.p1": "Karma Dental Clinic is a dental practice in Hydra, Alger, Algeria. We are open 24 hours a day, 7 days a week, whenever dental needs arise.",
      "about.p2": "The clinic is at Chemin de la Madeleine, Villa N12, Bourssace, Hydra 16016. Routine care or urgent attention — the team is here.",
      "about.call": "Call",
      "about.orwa": "or WhatsApp for the fastest response.",
      "about.stat1": "OPEN EVERY DAY",
      "about.stat2": "ALGER, ALGERIA",
      "why.title": "WHY CHOOSE US",
      "why.link": "CALL TODAY",
      "why.b1.title": "OPEN 24 HOURS",
      "why.b1.desc": "Care around the clock. No need to wait until morning when pain strikes at night.",
      "why.b2.title": "CENTRAL HYDRA",
      "why.b2.desc": "Chemin de la Madeleine, Villa N12, Bourssace, Hydra 16016 — easy to reach in Alger.",
      "why.b3.title": "DIRECT CONTACT",
      "why.b3.desc": "Call or WhatsApp 0774080545. Speak directly with the clinic.",
      "why.b4.title": "PROFESSIONAL CARE",
      "why.b4.desc": "Quality dental care in a modern clinical setting.",
      "reviews.title": "PATIENT FEEDBACK",
      "reviews.placeholder": "[ADD REAL TESTIMONIAL]",
      "reviews.author": "— Patient name",
      "contact.title": "CONTACT",
      "contact.link": "CALL 0774080545",
      "contact.phone": "PHONE",
      "contact.address": "ADDRESS",
      "contact.hours": "HOURS",
      "contact.hoursVal": "OPEN 24 HOURS<br>EVERY DAY",
      "contact.map": "MAP",
      "contact.mapHint": "Map below — Hydra, Alger",
      "contact.mapCta": "OPEN GOOGLE MAPS",
      "form.name": "NAME",
      "form.namePh": "YOUR NAME",
      "form.phone": "PHONE",
      "form.phonePh": "YOUR PHONE NUMBER",
      "form.message": "MESSAGE",
      "form.messagePh": "HOW CAN WE HELP?",
      "form.send": "SEND",
      "form.or": "Or call",
      "map.prompt": "FIND US IN HYDRA, ALGER",
      "map.cta": "OPEN GOOGLE MAPS",
      "footer.tag": "Open 24 hours · Hydra, Alger",
      "footer.copy": "© 2026 Karma Dental Clinic. All rights reserved.",
      "chat.launcher": "ASSISTANT",
      "chat.title": "CLINIC ASSISTANT",
      "chat.status": "Online · Spots · 24/7",
      "chat.closeAria": "Close assistant",
      "chat.inputLabel": "Message",
      "chat.placeholder": "Ask about a service or book a spot",
      "chat.send": "SEND",
      "chat.sendAria": "Send",
      "chat.you": "You",
      "chat.bot": "Assistant",
      "svc.general.label": "General dentistry",
      "svc.general.copy": "Check-ups, cleanings, and prevention. A typical visit is about 45 minutes.",
      "svc.emergency.label": "Emergency care",
      "svc.emergency.copy": "Pain, broken tooth, swelling, or trauma. Open 24 hours — calling is fastest.",
      "svc.cosmetic.label": "Cosmetic & restorative",
      "svc.cosmetic.copy": "Restore function and appearance. We start with a consultation.",
      "chip.book": "Book a spot",
      "chip.spots": "Open spots",
      "chip.services": "Services",
      "chip.emergency": "Emergency",
      "chip.hours": "Hours & location",
      "chip.mine": "My bookings",
      "chip.call": "Call " + PHONE,
      "chip.wa": "WhatsApp",
      "chip.stillBook": "Still book a slot",
      "chip.bookGeneral": "Book general",
      "chip.bookCosmetic": "Book cosmetic",
    },
  };

  let lang = localStorage.getItem(LANG_KEY) || "fr";
  if (lang !== "fr" && lang !== "en") lang = "fr";

  function t(key) {
    return (I18N[lang] && I18N[lang][key]) || I18N.fr[key] || key;
  }

  function applyI18n() {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      el.textContent = t(el.getAttribute("data-i18n"));
    });
    document.querySelectorAll("[data-i18n-html]").forEach((el) => {
      el.innerHTML = t(el.getAttribute("data-i18n-html"));
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      el.setAttribute("placeholder", t(el.getAttribute("data-i18n-placeholder")));
    });
    document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
      el.setAttribute("aria-label", t(el.getAttribute("data-i18n-aria")));
    });
    document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
      el.setAttribute("alt", t(el.getAttribute("data-i18n-alt")));
    });
    document.querySelectorAll(".lang-btn").forEach((btn) => {
      const on = btn.getAttribute("data-lang") === lang;
      btn.classList.toggle("is-on", on);
      btn.setAttribute("aria-pressed", on ? "true" : "false");
    });
    document.title =
      lang === "fr"
        ? "Karma Dental Clinic | Dentiste à Alger — Ouvert 24h/24"
        : "Karma Dental Clinic | Dentist in Alger — Open 24 Hours";
  }

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      lang = btn.getAttribute("data-lang") === "en" ? "en" : "fr";
      localStorage.setItem(LANG_KEY, lang);
      applyI18n();
      if (chat.greeted) {
        chat.log.innerHTML = "";
        chat.greet();
      }
    });
  });

  applyI18n();

  const SERVICES = ["general", "emergency", "cosmetic"];

  const menuBtn = document.getElementById("menuBtn");
  const menuClose = document.getElementById("menuClose");
  const mobileMenu = document.getElementById("mobileMenu");

  function openMenu() {
    mobileMenu.classList.add("open");
    mobileMenu.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
  function closeMenu() {
    mobileMenu.classList.remove("open");
    mobileMenu.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }
  if (menuBtn) menuBtn.addEventListener("click", openMenu);
  if (menuClose) menuClose.addEventListener("click", closeMenu);
  mobileMenu?.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", closeMenu);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (mobileMenu?.classList.contains("open")) closeMenu();
      if (chat.panel.classList.contains("open")) chat.close();
    }
  });

  const form = document.getElementById("contactForm");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = form.querySelector("#name");
      const phone = form.querySelector("#phone");
      const message = form.querySelector("#message");
      let valid = true;
      [name, phone, message].forEach((field) => {
        if (!field.value.trim()) {
          field.style.borderColor = "#ffc000";
          valid = false;
        } else field.style.borderColor = "";
      });
      if (!valid) return;
      form.reset();
      applyI18n();
      chat.open();
      chat.say(
        lang === "fr"
          ? "Message reçu. Pour une réponse immédiate, appelez le " + PHONE + " ou réservez une place ici."
          : "Message received. For the fastest help, call " + PHONE + " or book a spot here."
      );
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");
      if (targetId === "#" || targetId === "#chat") return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        const top = target.getBoundingClientRect().top + window.pageYOffset - 64;
        window.scrollTo({ top, behavior: "smooth" });
      }
    });
  });

  function loadBookings() {
    try {
      return JSON.parse(localStorage.getItem(STORE_KEY) || "[]");
    } catch {
      return [];
    }
  }
  function saveBookings(list) {
    localStorage.setItem(STORE_KEY, JSON.stringify(list));
  }
  function hash(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    return Math.abs(h);
  }
  function pad(n) {
    return String(n).padStart(2, "0");
  }
  function fmtDate(d) {
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }
  function prettyDate(iso) {
    const d = new Date(iso + "T12:00:00");
    return d.toLocaleDateString(lang === "fr" ? "fr-FR" : "en-GB", {
      weekday: "short",
      day: "numeric",
      month: "short",
    });
  }
  function timeLabel(h) {
    return pad(h) + ":00";
  }
  function seedTaken(date, hour) {
    return hash(date + "@" + hour) % 3;
  }
  function takenCount(date, hour) {
    const extra = loadBookings().filter((b) => b.date === date && b.hour === hour).length;
    return Math.min(CAPACITY, seedTaken(date, hour) + extra);
  }
  function spotsLeft(date, hour) {
    return Math.max(0, CAPACITY - takenCount(date, hour));
  }
  function nextDays(n) {
    const out = [];
    const now = new Date();
    for (let i = 0; i < n; i++) {
      const d = new Date(now);
      d.setDate(now.getDate() + i);
      out.push(fmtDate(d));
    }
    return out;
  }
  function daySpots(date) {
    return SLOT_HOURS.reduce((sum, h) => sum + spotsLeft(date, h), 0);
  }
  function upcomingSlots(limit) {
    const now = new Date();
    const list = [];
    for (const date of nextDays(5)) {
      for (const h of SLOT_HOURS) {
        const slot = new Date(date + "T" + timeLabel(h) + ":00");
        if (slot <= now) continue;
        const left = spotsLeft(date, h);
        if (left > 0) list.push({ date, hour: h, left });
        if (list.length >= limit) return list;
      }
    }
    return list;
  }
  function spotsWord(n) {
    if (lang === "fr") return n + (n > 1 ? " places" : " place");
    return n + (n === 1 ? " spot" : " spots");
  }

  const chat = {
    launcher: document.getElementById("chatLauncher"),
    panel: document.getElementById("chatPanel"),
    closeBtn: document.getElementById("chatClose"),
    log: document.getElementById("chatMessages"),
    quick: document.getElementById("chatQuick"),
    form: document.getElementById("chatForm"),
    input: document.getElementById("chatInput"),
    step: "idle",
    draft: {},
    greeted: false,

    open(service) {
      this.panel.classList.add("open");
      this.panel.setAttribute("aria-hidden", "false");
      this.launcher.classList.add("is-open");
      this.launcher.setAttribute("aria-expanded", "true");
      if (!this.greeted) {
        this.greet();
        this.greeted = true;
      }
      if (service === "emergency") this.handle("emergency");
      else if (service && SERVICES.includes(service)) {
        this.draft.service = service;
        this.step = "pick_date";
        this.say(t("svc." + service + ".label") + " — " + t("svc." + service + ".copy"));
        this.showDates();
      }
      this.input.focus();
    },
    close() {
      this.panel.classList.remove("open");
      this.panel.setAttribute("aria-hidden", "true");
      this.launcher.classList.remove("is-open");
      this.launcher.setAttribute("aria-expanded", "false");
    },
    greet() {
      const soon = upcomingSlots(3)
        .map((s) => prettyDate(s.date) + " " + timeLabel(s.hour) + " (" + spotsWord(s.left) + ")")
        .join(" · ");
      this.say(
        lang === "fr"
          ? "Bonjour — je suis l’assistant Karma. Je réserve une visite, j’affiche les places libres, ou j’explique nos soins. Cabinet ouvert 24h/24 à Hydra, Alger."
          : "Hi — I’m the Karma assistant. I can book a visit, show open spots, or explain our services. Open 24 hours in Hydra, Alger."
      );
      this.say(
        lang === "fr"
          ? "Prochaines places : " + (soon || "appelez le " + PHONE + ".")
          : "Next open spots: " + (soon || "call " + PHONE + ".")
      );
      this.showHomeChips();
    },
    showHomeChips() {
      this.setChips([
        { id: "book", label: t("chip.book") },
        { id: "spots", label: t("chip.spots") },
        { id: "services", label: t("chip.services") },
        { id: "emergency", label: t("chip.emergency") },
        { id: "hours", label: t("chip.hours") },
        { id: "mine", label: t("chip.mine") },
      ]);
    },
    setChips(items) {
      this.quick.innerHTML = "";
      items.forEach((item) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "chat-chip" + (item.full ? " full" : "") + (item.on ? " is-on" : "");
        b.textContent = item.label;
        b.disabled = !!item.disabled;
        b.addEventListener("click", () => this.onChip(item));
        this.quick.appendChild(b);
      });
    },
    bubble(role, text, extra) {
      const el = document.createElement("div");
      el.className = "chat-bubble " + role;
      const who = document.createElement("strong");
      who.textContent = role === "bot" ? t("chat.bot") : t("chat.you");
      el.appendChild(who);
      const p = document.createElement("div");
      p.textContent = text;
      el.appendChild(p);
      if (extra) el.appendChild(extra);
      this.log.appendChild(el);
      this.log.scrollTop = this.log.scrollHeight;
    },
    say(text, extra) {
      this.bubble("bot", text, extra);
    },
    echo(text) {
      this.bubble("user", text);
    },
    typing(fn) {
      const node = document.createElement("div");
      node.className = "chat-bubble bot chat-typing";
      node.innerHTML = "<span></span><span></span><span></span>";
      this.log.appendChild(node);
      this.log.scrollTop = this.log.scrollHeight;
      window.setTimeout(() => {
        node.remove();
        fn();
      }, 420);
    },
    onChip(item) {
      if (item.action === "date") {
        this.echo(prettyDate(item.date));
        this.draft.date = item.date;
        this.step = "pick_time";
        this.showTimes(item.date);
        return;
      }
      if (item.action === "time") {
        this.echo(timeLabel(item.hour));
        this.pickTime(item.hour);
        return;
      }
      if (item.action === "service") {
        this.echo(t("svc." + item.service + ".label"));
        this.pickService(item.service);
        return;
      }
      this.echo(item.label);
      this.handle(item.id);
    },
    pickService(id) {
      this.draft.service = id;
      if (id === "emergency") {
        this.step = "idle";
        this.emergency();
        return;
      }
      this.step = "pick_date";
      this.say(
        t("svc." + id + ".copy") +
          (lang === "fr"
            ? " Choisissez un jour — les chiffres indiquent les places restantes."
            : " Pick a day — numbers show remaining client spots.")
      );
      this.showDates();
    },
    showDates() {
      this.setChips(
        nextDays(7).map((date) => {
          const left = daySpots(date);
          return {
            action: "date",
            date,
            label: prettyDate(date) + " · " + spotsWord(left),
            disabled: left === 0,
          };
        })
      );
    },
    showTimes(date) {
      const now = new Date();
      this.say(
        lang === "fr"
          ? "Horaires du " + prettyDate(date) + ". Chaque créneau accueille " + CAPACITY + " patients."
          : "Open times on " + prettyDate(date) + ". Each slot holds " + CAPACITY + " clients."
      );
      this.setChips(
        SLOT_HOURS.map((h) => {
          const slot = new Date(date + "T" + timeLabel(h) + ":00");
          const left = spotsLeft(date, h);
          const past = slot <= now;
          const passed = lang === "fr" ? "passé" : "passed";
          const leftTxt = lang === "fr" ? left + " rest." : left + " left";
          return {
            action: "time",
            hour: h,
            label: timeLabel(h) + " · " + (past ? passed : leftTxt),
            disabled: past || left === 0,
            full: left === 0,
          };
        })
      );
    },
    pickTime(hour) {
      if (!this.draft.date) return;
      if (spotsLeft(this.draft.date, hour) <= 0) {
        this.say(
          lang === "fr" ? "Cette place vient d’être prise. Choisissez un autre horaire." : "That spot just filled. Pick another time."
        );
        this.showTimes(this.draft.date);
        return;
      }
      this.draft.hour = hour;
      this.step = "ask_name";
      this.say(
        lang === "fr"
          ? "Noté — " + prettyDate(this.draft.date) + " à " + timeLabel(hour) + ". À quel nom réserver ?"
          : "Got it — " + prettyDate(this.draft.date) + " at " + timeLabel(hour) + ". What name should we put on the booking?"
      );
      this.setChips([]);
    },
    emergency() {
      this.say(
        lang === "fr"
          ? "Gonflement, saignement, choc ou forte douleur : appelez maintenant. Nous sommes ouverts 24h/24. Une place réservée peut attendre — une urgence non."
          : "For swelling, bleeding, trauma, or severe pain, call now. We are open 24 hours. A booked spot can wait — an emergency should not."
      );
      this.setChips([
        { id: "call", label: t("chip.call") },
        { id: "wa", label: t("chip.wa") },
        { id: "book", label: t("chip.stillBook") },
      ]);
    },
    confirmBooking() {
      const svcId = this.draft.service || "general";
      if (spotsLeft(this.draft.date, this.draft.hour) <= 0) {
        this.say(
          lang === "fr"
            ? "Ce créneau s’est rempli. Choisissons un autre horaire."
            : "That slot filled while we were talking. Let’s pick another."
        );
        this.step = "pick_time";
        this.showTimes(this.draft.date);
        return;
      }
      const booking = {
        id: "KDC-" + Date.now().toString(36).toUpperCase(),
        name: this.draft.name,
        phone: this.draft.phone,
        service: svcId,
        date: this.draft.date,
        hour: this.draft.hour,
        created: new Date().toISOString(),
      };
      const list = loadBookings();
      list.push(booking);
      saveBookings(list);
      const card = document.createElement("div");
      card.className = "booking-card";
      card.textContent =
        booking.id +
        " · " +
        t("svc." + svcId + ".label") +
        " · " +
        prettyDate(booking.date) +
        " " +
        timeLabel(booking.hour) +
        " · " +
        booking.name;
      this.say(
        lang === "fr"
          ? "Place réservée. La clinique confirmera par téléphone. Pour un changement le jour même, appelez le " + PHONE + "."
          : "Spot reserved. The clinic will confirm by phone. For same-day changes call " + PHONE + ".",
        card
      );
      this.draft = {};
      this.step = "idle";
      this.showHomeChips();
    },
    listMine() {
      const mine = loadBookings();
      if (!mine.length) {
        this.say(
          lang === "fr"
            ? "Aucun rendez-vous enregistré sur cet appareil. Voulez-vous réserver une place ?"
            : "No bookings saved on this device yet. Want to reserve a spot?"
        );
        this.showHomeChips();
        return;
      }
      mine.slice(-5).forEach((b) => {
        this.say(
          b.id +
            " — " +
            t("svc." + (b.service || "general") + ".label") +
            (lang === "fr" ? " le " : " on ") +
            prettyDate(b.date) +
            (lang === "fr" ? " à " : " at ") +
            timeLabel(b.hour) +
            (lang === "fr" ? " pour " : " for ") +
            b.name +
            "."
        );
      });
      this.showHomeChips();
    },
    intent(text) {
      const raw = text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (/\b(emergenc|urgence|pain|douleur|swollen|saign|bleed|broken|casse|trauma)\b/.test(raw)) return "emergency";
      if (/\b(my booking|mes rdv|mes rendez|reservation)\b/.test(raw)) return "mine";
      if (/\b(spot|place|disponib|availab|horaire libre|creaneau|creneau)\b/.test(raw)) return "spots";
      if (/\b(book|appoint|rdv|rendez|reserve|reserver)\b/.test(raw)) return "book";
      if (/\b(hour|open|24|ouvert|horaire)\b/.test(raw)) return "hours";
      if (/\b(where|address|location|hydra|alger|adresse|ou etes)\b/.test(raw)) return "hours";
      if (/\b(whatsapp|wa)\b/.test(raw)) return "wa";
      if (/\b(call|phone|appel|numero)\b/.test(raw)) return "call";
      if (/\b(service|soin|clean|checkup|esthet|cosmetic|general|detartr)\b/.test(raw)) return "services";
      if (/\b(cancel|annul)\b/.test(raw)) return "cancel";
      if (/\b(hi|hello|hey|bonjour|salut|bonsoir)\b/.test(raw)) return "hello";
      return "unknown";
    },
    handle(id) {
      if (id === "hello") {
        this.greet();
        return;
      }
      if (id === "book") {
        this.step = "pick_service";
        this.say(lang === "fr" ? "Pour quel type de soin ?" : "Which service is this visit for?");
        this.setChips([
          { action: "service", service: "general", label: t("svc.general.label") },
          { action: "service", service: "emergency", label: t("svc.emergency.label") },
          { action: "service", service: "cosmetic", label: t("svc.cosmetic.label") },
        ]);
        return;
      }
      if (id === "spots") {
        const lines = nextDays(5).map((d) => prettyDate(d) + " : " + spotsWord(daySpots(d)));
        this.say(
          (lang === "fr"
            ? "Places patients sur les prochains jours (2 par créneau) : "
            : "Client spots for the next days (2 per hourly slot): ") + lines.join(" · ")
        );
        this.step = "pick_date";
        this.say(lang === "fr" ? "Touchez un jour pour voir les horaires." : "Tap a day to see exact times.");
        this.showDates();
        return;
      }
      if (id === "services") {
        this.say(
          lang === "fr"
            ? "Dentisterie générale — contrôles et détartrage. Urgences — 24h/24. Esthétique & restauration — apparence et réparation. Je peux retenir une place."
            : "General dentistry — check-ups and cleanings. Emergency care — 24/7. Cosmetic & restorative — appearance and repair. I can hold a spot."
        );
        this.step = "pick_service";
        this.setChips([
          { action: "service", service: "general", label: t("chip.bookGeneral") },
          { action: "service", service: "emergency", label: t("chip.emergency") },
          { action: "service", service: "cosmetic", label: t("chip.bookCosmetic") },
        ]);
        return;
      }
      if (id === "emergency") {
        this.emergency();
        return;
      }
      if (id === "hours") {
        this.say(
          lang === "fr"
            ? "Ouvert 24h/24, tous les jours. Chemin de la Madeleine, Villa N12, Bourssace, Hydra 16016, Alger. Les rendez-vous ont des créneaux ; les urgences peuvent appeler à tout moment."
            : "Open 24 hours, every day. Chemin de la Madeleine, Villa N12, Bourssace, Hydra 16016, Alger. Appointments use timed spots; emergencies can call anytime."
        );
        this.showHomeChips();
        return;
      }
      if (id === "call") {
        window.location.href = "tel:" + PHONE;
        this.say(lang === "fr" ? "Ouverture de l’appel vers " + PHONE + "." : "Opening the phone dialer for " + PHONE + ".");
        return;
      }
      if (id === "wa") {
        window.open(WA, "_blank", "noopener");
        this.say(lang === "fr" ? "Ouverture de WhatsApp." : "Opening WhatsApp.");
        return;
      }
      if (id === "mine") {
        this.listMine();
        return;
      }
      if (id === "cancel") {
        this.say(
          lang === "fr"
            ? "Pour modifier ou annuler, appelez le " + PHONE + " afin de libérer la place."
            : "To change or cancel, call " + PHONE + " so the chair can be freed."
        );
        this.setChips([
          { id: "call", label: t("chip.call") },
          { id: "mine", label: t("chip.mine") },
        ]);
        return;
      }
      this.say(
        lang === "fr"
          ? "Je peux réserver une place, montrer les disponibilités, expliquer les soins, ou vous passer le téléphone. De quoi avez-vous besoin ?"
          : "I can book a spot, show availability, explain services, or put you through by phone. What do you need?"
      );
      this.showHomeChips();
    },
    fromText(raw) {
      const text = raw.trim();
      if (!text) return;
      this.echo(text);
      this.typing(() => {
        if (this.step === "ask_name") {
          this.draft.name = text;
          this.step = "ask_phone";
          this.say(
            lang === "fr"
              ? "Merci, " + text + ". Quel numéro pour la confirmation ?"
              : "Thanks, " + text + ". Best phone number for confirmation?"
          );
          return;
        }
        if (this.step === "ask_phone") {
          this.draft.phone = text;
          if (!this.draft.service) this.draft.service = "general";
          this.confirmBooking();
          return;
        }
        if (this.step === "pick_service") {
          const x = text.toLowerCase();
          if (/emerg|urgenc|pain|douleur/.test(x)) return this.pickService("emergency");
          if (/cosmet|whit|restor|esthet/.test(x)) return this.pickService("cosmetic");
          if (/general|clean|check|detartr/.test(x)) return this.pickService("general");
        }
        const intent = this.intent(text);
        if (intent === "unknown" && this.step === "pick_date") {
          this.say(
            lang === "fr"
              ? "Touchez un jour avec des places, ou écrivez « places »."
              : "Please tap a day with open spots, or type “spots”."
          );
          this.showDates();
          return;
        }
        this.step = "idle";
        this.handle(intent);
      });
    },
  };

  chat.launcher.addEventListener("click", () => chat.open());
  chat.closeBtn.addEventListener("click", () => chat.close());
  chat.form.addEventListener("submit", (e) => {
    e.preventDefault();
    const v = chat.input.value;
    chat.input.value = "";
    chat.fromText(v);
  });
  document.querySelectorAll(".js-open-chat").forEach((el) => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      chat.open(el.getAttribute("data-service") || "");
    });
  });
  document.getElementById("menuBook")?.addEventListener("click", (e) => {
    e.preventDefault();
    closeMenu();
    chat.open();
  });
})();
