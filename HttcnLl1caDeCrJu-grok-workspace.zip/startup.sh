#!/bin/sh
# Serve the Karma Dental Clinic static site for live preview.
set -e
if curl -sf -o /dev/null http://127.0.0.1:8080/; then
  exit 0
fi
cd /workspace/artifacts
python3 -m http.server 8080 --bind 0.0.0.0 >/tmp/clinic-preview.log 2>&1 &
# wait until ready
for i in 1 2 3 4 5 6 7 8 9 10; do
  if curl -sf -o /dev/null http://127.0.0.1:8080/; then
    exit 0
  fi
  sleep 0.2
done
exit 0
